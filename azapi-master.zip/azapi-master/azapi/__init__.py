from .azapi import AZlyrics

__name__ = 'azapi.azapi.AZlyrics'
__author__ = 'Khaled H. El-Morshedy'
__url__ = 'https://github.com/elmoiv/azapi'
__description__ = 'Get Lyrics from AZLyrics.com like a Boss ~(0_0)~'
__license__ = 'GPL-v3.0'
__version__ = '3.0.7'
